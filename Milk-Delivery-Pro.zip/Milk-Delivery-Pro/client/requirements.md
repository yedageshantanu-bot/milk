## Packages
recharts | For the milk quantity bar chart
jspdf | For generating PDF bills
jspdf-autotable | Helper for tables in PDF (optional but good for future)
framer-motion | For smooth animations and transitions

## Notes
- Authentication uses a custom PIN for owner and username/password for customers.
- PDF generation needs to happen client-side using user data.
- Excel download is a CSV generation.
- WhatsApp sharing is a simple `wa.me` link.
